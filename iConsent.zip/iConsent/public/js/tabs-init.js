/**
 * Created by aisaenko on 15-01-17.
 */
$(function() {
    $( "#tabs" ).tabs();
});
